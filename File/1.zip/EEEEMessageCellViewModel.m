//
//  EEEEMessageCellViewModel.m
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import "EEEEMessageCellViewModel.h"
#import "EEEEModule_settingsModel.h"

@interface EEEEMessageCellViewModel ()
@property (nonatomic, strong) EEEEModule_settingsModel *model;
@end
@implementation EEEEMessageCellViewModel
- (instancetype)initWithModel:(EEEEModule_settingsModel *)model {
    if (self=[super init]) {
        
        self.model = model;
        self.name = model.name;
        self.type = model.type;
        self.status = model.status;
        
    }
    return self;
}



- (NSUInteger)cellHeight {
    
    return 0;
    
}
@end

//
//  EEEEMessageCellCoordinator.h
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class EEEEMessageCellView;
@class EEEEMessageCellViewModel;
@interface EEEEMessageCellCoordinator : NSObject
- (instancetype)initWithCellView:(EEEEMessageCellView *)cell;
- (void)bindData:(EEEEMessageCellViewModel *)cellViewModel;
- (void)didSelectCellView;
@end

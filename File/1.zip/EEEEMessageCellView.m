//
//  EEEEMessageCellView.m
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import "EEEEMessageCellView.h"

@interface EEEEMessageCellView ()

@end
@implementation EEEEMessageCellView

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubViews];
    }
    return self;
}

- (void)initSubViews {
    
}




- (void)setName:(NSString *)name {
    _name = name;
}

- (void)setType:(NSNumber *)type {
    _type = type;
}

- (void)setStatus:(NSNumber *)status {
    _status = status;
}




@end

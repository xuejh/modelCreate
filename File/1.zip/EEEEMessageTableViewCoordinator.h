//
//  EEEEMessageTableViewCoordinator.h
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface EEEEMessageTableViewCoordinator : NSObject

- (instancetype)initWithTableView:(UITableView *)tableView;

@end

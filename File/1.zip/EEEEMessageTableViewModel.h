//
//  EEEEMessageTableViewModel.h
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class EEEEMessageCellViewModel;
@interface EEEEMessageTableViewModel : NSObject
@property (nonatomic, strong, readonly) NSArray<EEEEMessageCellViewModel *> *cellViewModelList;  //Model
- (void)fetchData;
@end

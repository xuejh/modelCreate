//
//  EEEEMessageContext.m
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import "EEEEMessageContext.h"

@interface EEEEMessageContext ()
@property(nonatomic, weak) UIViewController *controller;
@end
@implementation EEEEMessageContext
- (instancetype)initWithViewController:(UIViewController *)controller {
    if (self=[super init]) {
        self.controller = controller;
    }
    
    return self;
}
@end
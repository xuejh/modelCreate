//
//  EEEEMessageCellViewModel.h
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import <Foundation/Foundation.h>


@class EEEEModule_settingsModel;
@interface EEEEMessageCellViewModel : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *type;
@property (nonatomic, strong) NSNumber *status;


- (instancetype)initWithModel:(EEEEModule_settingsModel *)model;
- (NSUInteger)cellHeight;
@end

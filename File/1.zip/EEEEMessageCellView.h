//
//  EEEEMessageCellView.h
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface EEEEMessageCellView : UITableViewCell

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *type;
@property (nonatomic, strong) NSNumber *status;


@end

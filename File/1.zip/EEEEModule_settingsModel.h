//
//  EEEEModule_settingsModel.h
//
//  https://github.com/xuejh/modelCreate
//
//  Copyright (c) Xuejinhui All rights reserved.
//


#import <Foundation/Foundation.h>

@interface EEEEModule_settingsModel : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *type;
@property (nonatomic, strong) NSNumber *status;

/**
 *  Init the model with dictionary
 *
 *  @param dictionary dictionary
 *
 *  @return model
 */
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end


//
//  EEEEMessageViewController.m
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import "EEEEMessageViewController.h"
#import "EEEEMessageTableViewCoordinator.h"
#import "UIResponder+Router.h"
#import "UIView+Context.h"
#import "EEEEMessageContext.h"

@interface EEEEMessageViewController ()
@property (nonatomic, strong) EEEEMessageTableViewCoordinator *tableViewCD;
@end

@implementation EEEEMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.context = [[EEEEMessageContext alloc] initWithViewController:self];
    
    // Do any additional setup after loading the view.
    [self installSubModule];
    
    
}

- (void)installSubModule {
    [self installTableViewModule];
}

- (void)installTableViewModule {
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height)];
    tableView.tableFooterView = [[UIView alloc] init];
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:tableView];
    
    self.tableViewCD = [[EEEEMessageTableViewCoordinator alloc] initWithTableView:tableView];
}



- (void)routeEvent:(NSString *)eventName userInfo:(NSDictionary *)userInfo {
    //拦截事件
    
}
@end

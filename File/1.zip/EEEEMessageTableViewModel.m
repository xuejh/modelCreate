//
//  EEEEMessageTableViewModel.m
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import "EEEEMessageTableViewModel.h"
#import "EEEEModule_settingsModel.h"
#import "EEEEMessageCellViewModel.h"

@interface EEEEMessageTableViewModel ()
@property (nonatomic, strong) NSArray<EEEEMessageCellViewModel *> *cellViewModelList;  //Model
@end
@implementation EEEEMessageTableViewModel
- (void)fetchData {
    
    
}

- (NSArray *)convertToCellViewModels:(NSArray<EEEEModule_settingsModel *> *)array {
    
    NSMutableArray *cellVMArray = [NSMutableArray array];
    for (int i=0; i<[array count]; i++) {
        EEEEModule_settingsModel *model = array[i];
        EEEEMessageCellViewModel *cellViewModel = [EEEEMessageTableViewModel createCellViewModel:model];
        
        [cellVMArray addObject:cellViewModel];
    }
    return cellVMArray;
}

- (NSArray<EEEEModule_settingsModel *> *)fetchDataList {
    
    return nil;
}

+ (EEEEMessageCellViewModel *)createCellViewModel:(EEEEModule_settingsModel *)model {
    EEEEMessageCellViewModel *cellViewModel = [[EEEEMessageCellViewModel alloc] initWithModel:model];
    
    return cellViewModel;
}
@end

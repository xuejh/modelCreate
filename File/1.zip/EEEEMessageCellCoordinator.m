//
//  EEEEMessageCellCoordinator.m
//  AppFramework
//
//  Created by xuejinhui 
//  Copyright © 2018年 nd. All rights reserved.
//

#import "EEEEMessageCellCoordinator.h"
#import "EEEEMessageCellView.h"
#import "EEEEMessageCellViewModel.h"
#import "UIView+Context.h"
#import "EEEEMessageContext.h"
#import <KVOController/FBKVOController.h>
#import <MBProgressHUD/MBProgressHUD.h>

@interface EEEEMessageCellCoordinator ()
@property(nonatomic, weak) EEEEMessageCellView *cell;
@property(nonatomic, weak) EEEEMessageCellViewModel *cellViewModel;
@property(nonatomic, strong) FBKVOController *kvoController;
@end
@implementation EEEEMessageCellCoordinator
- (instancetype)initWithCellView:(EEEEMessageCellView *)cell {
    if (self = [super init]) {
        self.cell = cell;
    }
    return self;
}

- (void)bindData:(EEEEMessageCellViewModel *)cellViewModel {
    [_kvoController unobserveAll];
    self.cellViewModel = cellViewModel;
    self.cell.name = cellViewModel.name;
    self.cell.type = cellViewModel.type;
    self.cell.status = cellViewModel.status;
    
}

- (void)didSelectCellView {
    
}



- (FBKVOController *)kvoController {
    if (!_kvoController) {
        _kvoController = [[FBKVOController alloc] initWithObserver:self retainObserved:YES];
    }
    
    return _kvoController;
}
@end

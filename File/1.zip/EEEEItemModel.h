//
//  EEEEItemModel.h
//
//  https://github.com/xuejh/modelCreate
//
//  Copyright (c) Xuejinhui All rights reserved.
//


#import <Foundation/Foundation.h>
#import "EEEEModule_settingsModel.h"

@interface EEEEItemModel : NSObject

@property (nonatomic, strong) NSNumber *client_id;
@property (nonatomic, strong) NSNumber *org_type;
@property (nonatomic, strong) NSNumber *org_id;
@property (nonatomic, strong) NSString *vorg_id;
@property (nonatomic, strong) NSString *v_org_id;
@property (nonatomic, strong) NSMutableArray <EEEEModule_settingsModel *> *module_settings;

/**
 *  Init the model with dictionary
 *
 *  @param dictionary dictionary
 *
 *  @return model
 */
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

